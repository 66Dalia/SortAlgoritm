#include "NewsArray.hpp"
#include <iostream>
#include <algorithm>

// Constructor to initialize the dynamic array with a default capacity of 10
DynamicArray::DynamicArray() : capacity(10), size(0) {
    array = new NewsNode * [capacity];
}
// Destructor to free the memory allocated for the dynamic array
DynamicArray::~DynamicArray() {
    delete[] array;
}
// Resize the dynamic array by doubling its capacity
void DynamicArray::resize() {
    capacity *= 2;
    NewsNode** newArray = new NewsNode * [capacity];
    for (int i = 0; i < size; i++) {
        newArray[i] = array[i];
    }
    delete[] array;
    array = newArray;
}
// Insert a news node into the dynamic array
void DynamicArray::insert(NewsNode* newsNode) {
    if (size >= capacity) {
        resize();
    }
    array[size++] = newsNode;
}
// Display the contents of the dynamic array
void DynamicArray::display() const {
    for (int i = 0; i < size; i++) {
        std::cout << "Title: " << array[i]->title << "\n"
            << "Subject: " << array[i]->subject << "\n"
            << "Date: " << array[i]->date << "\n"
            << "Text: " << array[i]->text << "\n"
            << "Type: " << (array[i]->isTrue ? "True News" : "Fake News") << "\n"
            << "--------------------------\n";
    }
}
// Get the total number of entries in the dynamic array
int DynamicArray::getSize() const {
    return size;
}
// Partition the array and return the pivot index
int DynamicArray::partition(int low, int high) {
    NewsNode* pivot = array[high];
    int i = low - 1;
    for (int j = low; j < high; j++) {
        if (array[j]->date < pivot->date) {
            i++;
            std::swap(array[i], array[j]);
        }
    }
    std::swap(array[i + 1], array[high]);
    return i + 1;
}
// Recursive function to perform QuickSort
void DynamicArray::quickSort(int low, int high) {
    if (low < high) {
        int pi = partition(low, high);
        quickSort(low, pi - 1);
        quickSort(pi + 1, high);
    }
}
// Sort the dynamic array using QuickSort
void DynamicArray::sort() {
    quickSort(0, size - 1);
} // End of NewsArray.cpp
