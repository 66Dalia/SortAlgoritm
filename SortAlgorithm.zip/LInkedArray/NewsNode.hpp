#ifndef NEWSNODE_HPP
#define NEWSNODE_HPP

#include <string>

// Structure for each node in the linked list
struct NewsNode {
    std::string title;
    std::string text;
    std::string subject;
    std::string date;
    bool isTrue; // true for true news, false for fake news
    NewsNode* next;

    // Constructor
    NewsNode(const std::string& t, const std::string& tx, const std::string& s, const std::string& d, bool truth)
        : title(t), text(tx), subject(s), date(d), isTrue(truth), next(nullptr) {
    }
};

#endif // NEWSNODE_HPP