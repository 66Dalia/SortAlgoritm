#ifndef DYNAMICARRAY_HPP
#define DYNAMICARRAY_HPP

#include "NewsNode.hpp"

class DynamicArray {
private:
    NewsNode** array;
    int capacity;
    int size;
    void resize();
    void quickSort(int low, int high);
    int partition(int low, int high);

public:
    DynamicArray();
    ~DynamicArray();
    void insert(NewsNode* newsNode);
    void display() const;
    int getSize() const;
    void sort(); // QuickSort wrapper
};

#endif // NEWSARRAY_HPP