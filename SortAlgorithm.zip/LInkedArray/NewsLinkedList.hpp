#ifndef LINKEDLIST_HPP
#define LINKEDLIST_HPP

#include "NewsNode.hpp"

class LinkedList {
private:
    NewsNode* head;
    int count;
    NewsNode* mergeSort(NewsNode* head);
    NewsNode* merge(NewsNode* left, NewsNode* right);

public:
    LinkedList();
    ~LinkedList();
    void insert(const std::string& title, const std::string& text, const std::string& subject, const std::string& date, bool isTrue);
    void display() const;
    int getCount() const;
    void sort(); // MergeSort wrapper
};

#endif // NEWSLINKEDLIST_HPP