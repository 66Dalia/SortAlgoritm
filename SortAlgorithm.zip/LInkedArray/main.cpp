#include "NewsNode.hpp"
#include "NewsLinkedList.hpp"
#include "NewsArray.hpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <chrono>

// Parse a quoted field from a CSV line
std::string parseQuotedField(std::stringstream& ss) {
    std::string field;
    if (ss.peek() == '"') {
        ss.get();
        std::getline(ss, field, '"');
        ss.get();
    }
    else {
        std::getline(ss, field, ',');
    }
    return field;
}

/**
 * Reads data from a CSV file and stores it in both a linked list and a dynamic array.
 * Each row represents a news article with title, text, subject, and publication date.
 * The parsed data is inserted into the appropriate data structures for sorting and processing.
 * @param filename The name of the CSV file to be processed.
 * @param list The linked list to store the news articles.
 * @param array The dynamic array to store the news articles.
 * @param isTrue Boolean flag indicating whether the news is true (true.csv) or fake (fake.csv).
 */ 

void processCSV(const std::string& filename, LinkedList& list, DynamicArray& array, bool isTrue) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Failed to open the CSV file: " << filename << std::endl;
        return;
    }

    std::string line;
    getline(file, line); // Skip the header line

    while (getline(file, line)) {
        std::stringstream ss(line);
        std::string title, text, subject, date;

        title = parseQuotedField(ss);
        text = parseQuotedField(ss);
        subject = parseQuotedField(ss);
        date = parseQuotedField(ss);

        NewsNode* node = new NewsNode(title, text, subject, date, isTrue);
        list.insert(title, text, subject, date, isTrue);
        array.insert(node);
    }

    file.close();
} 

// Main function to test the linked list and dynamic array implementations
int main() {
    LinkedList newsList;
    DynamicArray newsArray;

    processCSV("true.csv", newsList, newsArray, true);
    processCSV("fake.csv", newsList, newsArray, false);

    // Measure the time taken to sort the linked list and dynamic array
    auto start = std::chrono::high_resolution_clock::now();
    newsList.sort();
    auto end = std::chrono::high_resolution_clock::now(); 
    std::cout << "Time taken to sort Linked List: " << std::chrono::duration_cast<std::chrono::seconds>(end - start).count() << "s\n";

    start = std::chrono::high_resolution_clock::now();
    newsArray.sort();
    end = std::chrono::high_resolution_clock::now();
    std::cout << "Time taken to sort Dynamic Array: " << std::chrono::duration_cast<std::chrono::seconds>(end - start).count() << "s\n";
    
    // Display the sorted linked list and dynamic array
    std::cout << "\nDisplaying sorted Linked List:\n";
    newsList.display();

    std::cout << "\nDisplaying sorted Dynamic Array:\n";
    newsArray.display();

    // Output the total number of entries in the linked list and dynamic array
    std::cout << "\nTotal entries in Linked List: " << newsList.getCount() << "\n\n";
    std::cout << "Total entries in Dynamic Array: " << newsArray.getSize() << "\n";
    
    return 0;
} 