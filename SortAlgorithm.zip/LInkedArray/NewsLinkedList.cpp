#include "NewsLinkedList.hpp"
#include <iostream>

LinkedList::LinkedList() : head(nullptr), count(0) {}

LinkedList::~LinkedList() {
    NewsNode* current = head;
    while (current != nullptr) {
        NewsNode* temp = current;
        current = current->next;
        delete temp;
    }
}

void LinkedList::insert(const std::string& title, const std::string& text, const std::string& subject, const std::string& date, bool isTrue) {
    NewsNode* newNode = new NewsNode(title, text, subject, date, isTrue);
    if (!head) {
        head = newNode;
    }
    else {
        NewsNode* temp = head;
        while (temp->next != nullptr) {
            temp = temp->next;
        }
        temp->next = newNode;
    }
    count++;
}

void LinkedList::display() const {
    NewsNode* temp = head;
    while (temp != nullptr) {
        std::cout << "Title: " << temp->title << "\n"
            << "Subject: " << temp->subject << "\n"
            << "Date: " << temp->date << "\n"
            << "Text: " << temp->text << "\n"
            << "Type: " << (temp->isTrue ? "True News" : "Fake News") << "\n"
            << "--------------------------\n";
        temp = temp->next;
    }
}

int LinkedList::getCount() const {
    return count;
}
// Merge two sorted linked lists
NewsNode* LinkedList::merge(NewsNode* left, NewsNode* right) {
    if (!left) {
        return right;
    }
    if (!right) {
        return left;
    }
    NewsNode* result = nullptr;
    if (left->date < right->date) {
        result = left;
        result->next = merge(left->next, right);
    }
    else {
        result = right;
        result->next = merge(left, right->next);
    }
    return result;
}
// MergeSort algorithm
// Time complexity: O(n log n)
NewsNode* LinkedList::mergeSort(NewsNode* head) { 
    if (!head || !head->next) { 
        return head;
    } 
    // Split the list into two halves
    NewsNode* middle = head; // Find the middle of the list
    NewsNode* fast = head->next; 
    while (fast && fast->next) { // fast pointer moves twice as fast as the slow pointer
        middle = middle->next; 
        fast = fast->next->next; 
    } 
    NewsNode* left = head;
    NewsNode* right = middle->next;
    middle->next = nullptr; 
    left = mergeSort(left); 
    right = mergeSort(right); // Merge the two sorted halves
    return merge(left, right); // Return the sorted list
} 

void LinkedList::sort() {
    head = mergeSort(head); // MergeSort the linked list
}