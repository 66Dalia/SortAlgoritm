// array_analysis.cpp
#include "array_analysis.h"
#include "hybrid_search.h"
#include <iostream>
#include <ctime>

void measureSearchTime(char arr[][50], int size, const char target[]) {
    clock_t start = clock();
    hybridSearch(arr, size, target);
    clock_t end = clock();
    double duration = ((double)(end - start) / CLOCKS_PER_SEC) * 1000000; // Convert to microseconds
    std::cout << "Search Execution Time: " << duration << " microseconds\n";
}
