// array_search.cpp

#include <iostream>
#include <cstring>

// Structure for tracking search frequency
struct SearchRecord {
    char word[50];
    int count;
};

// Manually maintain a fixed-size array to track search frequencies
#define MAX_RECORDS 100
SearchRecord searchRecords[MAX_RECORDS];
int recordCount = 0;

// Binary Search for the target word in the sorted array.
int binarySearch(char arr[][50], int size, const char target[]) {
    int left = 0, right = size - 1;
    while (left <= right) {
        int mid = left + (right - left) / 2;
        int cmp = strcmp(arr[mid], target);
        if (cmp == 0)
            return mid;
        else if (cmp < 0)
            left = mid + 1;
        else
            right = mid - 1;
    }
    return -1;  // Not found
}

// Linear Search for the target word in the array.
bool linearSearch(char arr[][50], int size, const char target[]) {
    for (int i = 0; i < size; i++) {
        if (strcmp(arr[i], target) == 0)
            return true;
    }
    return false;
}

// Hybrid Search: Uses Binary Search first (if array is sorted), then falls back to Linear Search.
// Also updates search frequency tracking.
bool hybridSearch(char arr[][50], int size, const char target[]) {
    // Update search frequency record
    bool foundRecord = false;
    for (int i = 0; i < recordCount; i++) {
        if (strcmp(searchRecords[i].word, target) == 0) {
            searchRecords[i].count++;
            foundRecord = true;
            break;
        }
    }
    if (!foundRecord && recordCount < MAX_RECORDS) {
        strcpy(searchRecords[recordCount].word, target);
        searchRecords[recordCount].count = 1;
        recordCount++;
    }

    // Use binary search first
    int idx = binarySearch(arr, size, target);
    if (idx != -1)
        return true;
    // Fall back to linear search if binary search fails
    return linearSearch(arr, size, target);
}

// Display the top 5 most searched words.
void displayTopSearches() {
    std::cout << "\nTop 5 Most Searched Words:\n";
    int limit = (recordCount < 5) ? recordCount : 5;
    for (int i = 0; i < limit; i++) {
        std::cout << searchRecords[i].word << " : " << searchRecords[i].count << " times\n";
    }
}
