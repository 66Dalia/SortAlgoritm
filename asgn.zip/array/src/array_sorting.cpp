// array_sorting.cpp
#include "array_sorting.h"
#include <cstring>

void bubbleSort(char arr[][50], int size) {
    for (int i = 0; i < size - 1; i++) {
        for (int j = 0; j < size - i - 1; j++) {
            // Compare strings using strcmp; if arr[j] is greater, swap them.
            if (strcmp(arr[j], arr[j+1]) > 0) {
                char temp[50];
                strcpy(temp, arr[j]);
                strcpy(arr[j], arr[j+1]);
                strcpy(arr[j+1], temp);
            }
        }
    }
}

