// array_memory.cpp
#include "array_memory.h"
#include <iostream>

void measureMemoryUsage(int size) {
    // Each word is a char array of fixed length 50.
    std::cout << "Memory Usage (Array): " << size * 50 * sizeof(char) << " bytes\n";
}
