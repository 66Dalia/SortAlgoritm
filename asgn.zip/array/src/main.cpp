// main.cpp
#include "array_sorting.h"   // Contains the bubbleSort function
#include "hybrid_search.h"   // Contains binarySearch, linearSearch, hybridSearch, and displayTopSearches
#include "array_memory.h"    // Contains the measureMemoryUsage function
#include "array_analysis.h"  // Contains the measureSearchTime function
#include <iostream>
#include <fstream>
#include <cstring>
#include <ctime>

#define MAX_WORDS 10000   // Maximum number of words to load
#define MAX_LENGTH 50    // Maximum length for each word

// Function: loadDataset
// Purpose: Load words from the dataset file into a manually allocated 2D char array.
void loadDataset(const char* filename, char dataset[][MAX_LENGTH], int &size) {
    std::ifstream file(filename);
    if (!file) {
        std::cerr << "Error: Could not open dataset file: " << filename << "\n";
        size = 0;
        return;
    }
    size = 0;
    // Read word by word until file ends or MAX_WORDS is reached.
    while (file >> dataset[size] && size < MAX_WORDS) {
        size++;
    }
    file.close();
}

int main() {
    char dataset[MAX_WORDS][MAX_LENGTH]; // Raw array to store words
    int dataSize = 0;

    // Adjust the path if needed. For example, if your working directory is your project root:
    const char* datasetPath ="../data/true.csv";

    // Load the cleaned dataset provided by Member 1.
    loadDataset(datasetPath, dataset, dataSize);
    std::cout << "Loaded " << dataSize << " words from the dataset.\n";

    // If no words are loaded, exit the program.
    if (dataSize == 0) {
        std::cerr << "No data loaded. Exiting.\n";
        return 1;
    }

    // Sort the dataset using our manual Bubble Sort.
    bubbleSort(dataset, dataSize);
    std::cout << "Dataset sorted alphabetically.\n";

    // Prompt the user to enter a word to search.
    char target[MAX_LENGTH];
    std::cout << "Enter a word to search: ";
    std::cin >> target;

    // Measure execution time for a single call to hybridSearch.
    clock_t start = clock();
    bool found = hybridSearch(dataset, dataSize, target);
    clock_t end = clock();
    double duration = ((double)(end - start) / CLOCKS_PER_SEC) * 1000000; // microseconds

    std::cout << "Search Execution Time: " << duration << " microseconds\n";
    std::cout << "Word \"" << target << "\" "
              << (found ? "found" : "not found")
              << " in the dataset.\n";

    // Measure and display memory usage of the dataset array.
    measureMemoryUsage(dataSize);

    // Display the top 5 most frequently searched words.
    displayTopSearches();

    return 0;
}
