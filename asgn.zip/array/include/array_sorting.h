
#ifndef ARRAY_SORTING_H
#define ARRAY_SORTING_H
void bubbleSort(char arr[][50], int size);
#endif //ARRAY_SORTING_H
