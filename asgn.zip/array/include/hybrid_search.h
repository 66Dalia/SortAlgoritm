// array_search.h


#ifndef ARRAY_SEARCH_H
#define ARRAY_SEARCH_H

// Searches a sorted array of strings using Binary Search.
// Returns index if found, otherwise -1.
int binarySearch(char arr[][50], int size, const char target[]);

// Searches an array of strings using Linear Search.
// Returns true if the target is found.
bool linearSearch(char arr[][50], int size, const char target[]);

// Hybrid Search: First attempts Binary Search; if not found, falls back to Linear Search.
// Also tracks search frequency manually.
bool hybridSearch(char arr[][50], int size, const char target[]);

// Displays the top 5 most frequently searched words.
void displayTopSearches();

#endif
