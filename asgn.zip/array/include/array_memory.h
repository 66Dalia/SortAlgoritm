// array_memory.h
#ifndef ARRAY_MEMORY_H
#define ARRAY_MEMORY_H

// Function to measure memory usage for the raw array.
void measureMemoryUsage(int size);

#endif
