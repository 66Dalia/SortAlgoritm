// array_analysis.h
#ifndef ARRAY_ANALYSIS_H
#define ARRAY_ANALYSIS_H

// Function to measure execution time of the search operation.
void measureSearchTime(char arr[][50], int size, const char target[]);

#endif
