//
// Created by USER on 2/22/2025.
//

#ifndef LINKED_OPERATIONS_H
#define LINKED_OPERATIONS_H

#endif //LINKED_OPERATIONS_H
